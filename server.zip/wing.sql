-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- 생성 시간: 16-08-15 09:23
-- 서버 버전: 5.5.42
-- PHP 버전: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- 데이터베이스: `wing`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `account`
--

CREATE TABLE `account` (
  `no_acnt` int(11) NOT NULL,
  `id_acnt` varchar(255) NOT NULL,
  `pw_acnt` varchar(255) NOT NULL,
  `nick_acnt` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `account`
--

INSERT INTO `account` (`no_acnt`, `id_acnt`, `pw_acnt`, `nick_acnt`) VALUES
(1, 'id', 'pw', 'nick'),
(2, 'id2', 'pw', 'nick'),
(3, 'a', 'ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb', 'a'),
(13, 'b', '3e23e8160039594a33894f6564e1b1348bbd7a0088d42c4acb73eeaed59c009d', 'b'),
(14, 'asdfasdfa', '74b291b17858c12e422b0c4ee42d39b5677c18a1cd263afa2c2c0037968d2a75', 'qf'),
(15, 'knh4735', '9d4768c71a74a71685b15cc16faf607d5b78756b8b27c65557b1561a1417c09f', 'asdf');

-- --------------------------------------------------------

--
-- 테이블 구조 `device_info`
--

CREATE TABLE `device_info` (
  `no_di` int(11) NOT NULL,
  `acnt_di` int(11) NOT NULL,
  `token_di` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `device_info`
--

INSERT INTO `device_info` (`no_di`, `acnt_di`, `token_di`) VALUES
(19, 13, 'b'),
(84, 3, 'dBvqY2aYuoE:APA91bF6FTYheh826bfilp77IsRKTt5PCiUn7QgtkTGoytGTfwW-KckkXwBS7Dw9SM336E0flBmw2JMRkCUwgLoZ5gfLmT5UOa0GUU498J2tahyYYI0JL_BkdVQj5l7Eqkh6IjNye60a');

-- --------------------------------------------------------

--
-- 테이블 구조 `friend_req`
--

CREATE TABLE `friend_req` (
  `no_fr` int(11) NOT NULL,
  `from_fr` int(11) NOT NULL,
  `to_fr` int(11) NOT NULL,
  `msg_fr` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `notice`
--

CREATE TABLE `notice` (
  `no_ntc` int(11) NOT NULL,
  `title_ntc` text NOT NULL,
  `date_ntc` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `content_ntc` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `notice`
--

INSERT INTO `notice` (`no_ntc`, `title_ntc`, `date_ntc`, `content_ntc`) VALUES
(1, 'title', '2016-08-12 11:29:33', 'content');

-- --------------------------------------------------------

--
-- 테이블 구조 `public_info`
--

CREATE TABLE `public_info` (
  `no_pi` int(11) NOT NULL,
  `acnt_pi` int(11) NOT NULL,
  `name_pi` varchar(255) NOT NULL DEFAULT '비공개',
  `phone_pi` varchar(255) NOT NULL DEFAULT '비공개',
  `email_pi` varchar(255) NOT NULL DEFAULT '비공개',
  `intro_pi` text
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `public_info`
--

INSERT INTO `public_info` (`no_pi`, `acnt_pi`, `name_pi`, `phone_pi`, `email_pi`, `intro_pi`) VALUES
(1, 14, '비공개', '비공개', '비공개', '비공개'),
(2, 15, '비공개', '비공개', '비공개', '비공개');

-- --------------------------------------------------------

--
-- 테이블 구조 `sensitive_info`
--

CREATE TABLE `sensitive_info` (
  `no_si` int(11) NOT NULL,
  `acnt_si` int(11) NOT NULL,
  `name_si` varchar(255) NOT NULL,
  `phone_si` varchar(255) NOT NULL,
  `email_si` varchar(255) NOT NULL,
  `intro_si` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `sensitive_info`
--

INSERT INTO `sensitive_info` (`no_si`, `acnt_si`, `name_si`, `phone_si`, `email_si`, `intro_si`) VALUES
(2, 3, '14534E48F5DE43874F921DE3CB88CDDE', '329CF5FCE2FF40C2F36E7363BD3622CD', 'EBAB4C81FCCADFB53DF8CDA98D34A49D', ''),
(5, 13, '0C1E8D4760EB932046264243F0B5F4B7', '0C1E8D4760EB932046264243F0B5F4B7', '0C1E8D4760EB932046264243F0B5F4B7', '0C1E8D4760EB932046264243F0B5F4B7'),
(6, 14, 'B6F91DFB62D6F6B7CD1CF402202EA1D1', '97253ED64CDD909FFFDE5E3E79433AD5', '0BD9C95819102170118761ECA74B8553', 'B6F91DFB62D6F6B7CD1CF402202EA1D1'),
(7, 15, 'ECD0041ED51493F7679144662D94EDFC', '9AE81C0E9068539F72199CF51297B369', '44F4154A90DEB232770A7C272D1777C8', 'F40ABF73065F3D98011FC24FD84744DE');

-- --------------------------------------------------------

--
-- 테이블 구조 `test`
--

CREATE TABLE `test` (
  `a` varchar(255) CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16;

--
-- 테이블의 덤프 데이터 `test`
--

INSERT INTO `test` (`a`) VALUES
('EF1E7DE2D2C0E70AB667ED159C23C73B'),
('EF1E7DE2D2C0E70AB667ED159C23C73B');

-- --------------------------------------------------------

--
-- 테이블 구조 `wing_info`
--

CREATE TABLE `wing_info` (
  `no_wi` int(11) NOT NULL,
  `from_wi` int(11) NOT NULL,
  `to_wi` int(11) NOT NULL,
  `cnt_wi` int(11) NOT NULL DEFAULT '0',
  `turn_wi` tinyint(1) NOT NULL DEFAULT '1',
  `vibe_wi` tinyint(4) NOT NULL DEFAULT '1',
  `time_wi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `wing_info`
--

INSERT INTO `wing_info` (`no_wi`, `from_wi`, `to_wi`, `cnt_wi`, `turn_wi`, `vibe_wi`, `time_wi`) VALUES
(1, 1, 2, 0, 1, 1, '0000-00-00 00:00:00'),
(2, 3, 3, 53, 1, 1, '2016-08-15 07:14:16'),
(3, 3, 15, 1, 0, 1, '2016-08-15 07:10:46'),
(4, 15, 3, 9, 1, 1, '2016-08-15 07:14:18');

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`no_acnt`),
  ADD UNIQUE KEY `id_acnt` (`id_acnt`);

--
-- 테이블의 인덱스 `device_info`
--
ALTER TABLE `device_info`
  ADD PRIMARY KEY (`no_di`);

--
-- 테이블의 인덱스 `friend_req`
--
ALTER TABLE `friend_req`
  ADD PRIMARY KEY (`no_fr`);

--
-- 테이블의 인덱스 `notice`
--
ALTER TABLE `notice`
  ADD PRIMARY KEY (`no_ntc`);

--
-- 테이블의 인덱스 `public_info`
--
ALTER TABLE `public_info`
  ADD PRIMARY KEY (`no_pi`);

--
-- 테이블의 인덱스 `sensitive_info`
--
ALTER TABLE `sensitive_info`
  ADD PRIMARY KEY (`no_si`);

--
-- 테이블의 인덱스 `wing_info`
--
ALTER TABLE `wing_info`
  ADD PRIMARY KEY (`no_wi`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `account`
--
ALTER TABLE `account`
  MODIFY `no_acnt` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- 테이블의 AUTO_INCREMENT `device_info`
--
ALTER TABLE `device_info`
  MODIFY `no_di` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
--
-- 테이블의 AUTO_INCREMENT `friend_req`
--
ALTER TABLE `friend_req`
  MODIFY `no_fr` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- 테이블의 AUTO_INCREMENT `notice`
--
ALTER TABLE `notice`
  MODIFY `no_ntc` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- 테이블의 AUTO_INCREMENT `public_info`
--
ALTER TABLE `public_info`
  MODIFY `no_pi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- 테이블의 AUTO_INCREMENT `sensitive_info`
--
ALTER TABLE `sensitive_info`
  MODIFY `no_si` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- 테이블의 AUTO_INCREMENT `wing_info`
--
ALTER TABLE `wing_info`
  MODIFY `no_wi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;