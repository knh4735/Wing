<?php
	try {
	    $pdo = new PDO("mysql:host=localhost;port=8888;dbname=wing;charset=utf8",'root','root');
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch (Exception $e) {
	    echo $e->getMessage();
	}
?>