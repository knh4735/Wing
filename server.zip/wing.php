<?php

	include_once("./db_conn.php");
	include_once("./gcm_module.php");

	$apiKey = 'AIzaSyCi1keI0cbwrSA4Jpfhfsmbi_cifACc4s0';
	$title = "Wing";
	$extra = "";
	$req = $_GET;

	$cmd = $req['cmd']?$req['cmd']:"";

	$pusher = new GcmSender($apiKey, true);

	if($cmd === "test"){
		print_r(hash("sha256","a"));
/*
		$pw = $req['pw'];
		$query = "SELECT AES_DECRYPT(UNHEX(`a`),:pw) as val FROM `test`";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":pw"=>$pw));

		$result = $stmt->fetchAll();
		var_dump($result);*/
	}
	else if($cmd ==="insert"){
		$info = $req['info'];
		$pw = $req['pw'];
		$query = "INSERT INTO `test` (`a`) VALUES (HEX(AES_ENCRYPT(:info, :pw)))";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":info"=>$info, ":pw"=>$pw));
	}
//INSERT INTO `sensitive_info` (`acnt_si`, `name_si`, `phone_si`, `email_si`) VALUES ( 3,  HEX(AES_ENCRYPT('name', 'a')),  HEX(AES_ENCRYPT('phone', 'a')) ,  HEX(AES_ENCRYPT('email', 'a')))
	
	//로그인
	else if($cmd === "login"){

		$id = $req['id'];
		$pw = $req['pw'];

		if($id !== "" && $pw !== ""){
			$query = "SELECT * FROM `account` WHERE `id_acnt` = :id";
			$stmt = $pdo->prepare($query);
			$stmt->execute(array(":id"=>$id));

			$account = $stmt->fetchObject();

			if(hash("sha256",$pw) === $account->pw_acnt){
				$acnt = $account->no_acnt;
				$token = $req['token'];

				$query = "DELETE FROM `device_info` WHERE `token_di` = :token";
				$stmt = $pdo->prepare($query);
				$stmt->execute(array(":token"=>$token));


				$query = "INSERT INTO `device_info` (`acnt_di`, `token_di`) VALUES (:acnt, :token)";
				$stmt = $pdo->prepare($query);
				$stmt->execute(array(":acnt"=>$acnt, ":token"=>$token));

				$query = "SELECT `acnt_si`, AES_DECRYPT(UNHEX(`name_si`),:pw) as name_si, AES_DECRYPT(UNHEX(`phone_si`),:pw) as phone_si, AES_DECRYPT(UNHEX(`email_si`),:pw) as email_si, AES_DECRYPT(UNHEX(`intro_si`),:pw) as intro_si FROM `sensitive_info` WHERE `acnt_si` = :acnt";
				$stmt = $pdo->prepare($query);
				$stmt->execute(array(":pw"=>$pw, ":acnt"=>$acnt));

				$info = $stmt->fetchObject();

				$result->no_acnt = $acnt;
				$result->id_acnt = $account->id_acnt;
				$result->nick_acnt = $account->nick_acnt;
				$result->token = $token;
				$result->info = $info;

				print_r(json_encode(array("result"=>$result)));
			}

			else print_r(json_encode(array("result"=>"Wrong")));
		}

		else print_r(json_encode(array("result"=>"Error")));
	}

	//로그아웃 - 디바이스 정보만 제거
	else if($cmd === "logout"){

		$acnt = $req['acnt'];
		$token = $req['token'];

		$query = "DELETE FROM `device_info` WHERE `acnt_di` = :acnt AND `token_di` = :token";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt, ":token"=>$token));

		print_r(json_encode(array("result"=>"Success")));
	}

	//윙 보내기
	else if($req['cmd'] === "wing"){

		$fr = $req['from']; //윙한사람
		$to = $req['to']; //상대방


		$query = "SELECT `account`.`nick_acnt` as nick, `wing_info`.`cnt_wi` as cnt FROM `account` LEFT JOIN `wing_info` ON(`account`.`no_acnt` = `wing_info`.`from_wi` AND `wing_info`.`to_wi` = :to) WHERE `account`.`no_acnt` = :no";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$from, ":to"=>$to));

		$result = $stmt->fetchObject();
		$name = $result->nick;
		$cnt = $result->cnt;

		//윙한사람 윙개수+1, turn 0
		$query = "UPDATE `wing_info` SET `cnt_wi` = `cnt_wi` + 1, `turn_wi` = 0 WHERE `from_wi` = :fr AND `to_wi` = :to ";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":fr"=>$fr, ":to"=>$to));


		//상대방 turn 1, 시간 업데이트
		$query = "UPDATE `wing_info` SET `turn_wi` = 1, `time_wi` = NOW() WHERE `from_wi` = :fr AND `to_wi` = :to";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":fr"=>$to, ":to"=>$fr));

		print_r(json_encode(array("result"=>"Success")));

		//gcm 전송
		$query = "SELECT * FROM `device_info` WHERE `acnt_di` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$to));

		$gcm_token = array();

		while($result = $stmt->fetchObject()){
			$gcm_token[] = $result->token_di;
		}

		$pusher->setDevices($gcm_token);
		$message = "WING||".$fr."||".$name."||".$cnt."||".mktime();
		$response = $pusher->send($title, $message, $extra);


		//print_r(json_encode(array("result"=>$message)));
	//	print_r(json_encode($response));//array("id"=>$pusher->getDevices()));
	}

	//커스텀 윙 보내기
	else if($req['cmd'] === "customWing"){

		$fr = $req['from']; //윙한사람
		$to = $req['to']; //상대방
		$pattern = $req['pattern'];
//wing logic 추가 (자기거 +1, turn 0  - 상대방 turn 1 )

		$query = "SELECT `nick_acnt` FROM `account` WHERE `no_acnt` = :no";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$from));

		$name = $stmt->fetchObject();
		$name = $name->nick_acnt;

		//gcm 전송
		$query = "SELECT * FROM `device_info` WHERE `acnt_di` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$to));

		$gcm_token = array();

		while($result = $stmt->fetchObject()){
			$gcm_token[] = $result->token_di;
		}

		$pusher->setDevices($gcm_token);
		$message = "CUSTOMWING||".$fr."||".$name."||".$pattern."||".mktime();
		$response = $pusher->send($title, $message, $extra);

		print_r(json_encode(array("result"=>"Success")));

		//print_r(json_encode(array("result"=>$message)));
	//	print_r(json_encode($response));//array("id"=>$pusher->getDevices()));
	}


	//친구요청
	else if($cmd === "requestFriend"){

		$fr = $req['from'];
		$to = $req['to'];
		$msg = $req['msg'];

		$query = "SELECT COUNT(*) as cnt FROM `friend_req` WHERE `from_fr` = :fr AND `to_fr` = :to";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":fr" => $fr, ":to"=>$to));

		$cnt = $stmt->fetchObject();


		$query = "SELECT COUNT(*) as cnt FROM `wing_info` WHERE `from_wi` = :fr AND `to_wi` = :to";
		$friend_stmt = $pdo->prepare($query);
		$friend_stmt->execute(array(":fr" => $fr, ":to"=>$to));

		$friend_cnt = $friend_stmt->fetchObject();

		if($friend_cnt->cnt === "0"){
			if($cnt->cnt === "0"){
				$query = "INSERT INTO `friend_req` (`from_fr`, `to_fr`, `msg_fr`) VALUES (:fr, :to, :msg)";
				$stmt = $pdo->prepare($query);
				$stmt->execute(array(":fr" => $fr, ":to"=>$to, ":msg"=>$msg));


				$query = "SELECT * FROM `device_info` WHERE `acnt_di` = :acnt";
				$stmt = $pdo->prepare($query);
				$stmt->execute(array(":acnt"=>$to));

				$gcm_token = array();

				while($result = $stmt->fetchObject()){
					$gcm_token[] = $result->token_di;
				}

				$pusher->setDevices($gcm_token);
				$message = "FR||".$fr."||".$msg."||".mktime();
				$response = $pusher->send($title, $message, $extra);

				print_r(json_encode(array("result"=>"Success")));
			}
			else print_r(json_encode(array("result"=>"Already")));
		}
		else print_r(json_encode(array("result"=>"Friend")));

	}


	//요청 확인
	else if($cmd === "reqConfirm"){

		$flag = $req['flag'];
		$from = $req['from'];
		$to = $req['to'];

		//수락
		if($flag === "YES"){

			$query = "INSERT INTO `wing_info` (`from_wi`, `to_wi`) VALUES (:fr, :to), (:to, :fr)";
			$stmt = $pdo->prepare($query);
			$stmt->execute(array(":fr" => $from, ":to"=>$to));

			$query = "DELETE FROM `friend_req` WHERE `from_fr` = :fr AND `to_fr` = :to";
			$stmt = $pdo->prepare($query);
			$stmt->execute(array(":fr" => $from, ":to"=>$to));

			print_r(json_encode(array("result"=>"YES")));
		}
		//거절
		else if($flag === "NO"){
			$query = "DELETE FROM `friend_req` WHERE `from_fr` = :fr AND `to_fr` = :to";
			$stmt = $pdo->prepare($query);
			$stmt->execute(array(":fr" => $from, ":to"=>$to));

			print_r(json_encode(array("result"=>"NO")));
		}
		//???
		else print_r(json_encode(array("result"=>"Fail")));
	}


	//메인 화면 로드
	else if($cmd === "getWing"){

		$from = intval($req['from']);

		$arr = array();

		$query = "SELECT `wing_info`.*, `account`.`no_acnt`, `account`.`nick_acnt` FROM `wing_info` LEFT OUTER JOIN `account` ON (`wing_info`.`to_wi` = `account`.`no_acnt`) WHERE `from_wi` = :fr AND `turn_wi` = 1 ORDER BY `no_wi` ASC";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":fr" => $from));

		while($result = $stmt->fetchObject()){
			$arr[] = $result;
		}

		print_r(json_encode(array("result"=>$arr)));
	}


	//친구 검색
	else if($cmd === "searchFriend"){

		$target = $req['target'];

		$arr = array();

		$query = "SELECT `no_acnt`, `nick_acnt` FROM `account` WHERE `id_acnt` = :target";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":target" => $target));

		while($result = $stmt->fetchObject()){
			$arr[] = $result;
		}

		print_r(json_encode(array("result"=>$arr)));

	}


	//랭킹 로드
	else if($cmd === "getRank"){
		$id = $req['id'];


		$arr = array();

		$query = "SELECT `wing_info`.*, `account`.`nick_acnt` FROM `wing_info` LEFT OUTER JOIN `account` ON (`wing_info`.`to_wi` = `account`.`no_acnt`) WHERE `from_wi` = :id ORDER BY `cnt_wi` DESC";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":id" => $id));

		while($result = $stmt->fetchObject()){
			$arr[] = $result;
		}

		print_r(json_encode(array("result"=>$arr)));
	}

	//공지 로드 
	else if($cmd === "getNotice"){
		$arr = array();

		$query = "SELECT * FROM `notice` ORDER BY `date_ntc`";
		$stmt = $pdo->prepare($query);
		$stmt->execute();

		while($result = $stmt->fetchObject()){
			$arr[] = $result;
		}

		print_r(json_encode(array("result"=>$arr)));
	}

	//요청 목록 로드 
	else if($cmd === "getRequest"){

		$to = $req['acnt'];

		$arr = array();

		$query = "SELECT * FROM `friend_req` WHERE `to_fr` = :to ORDER BY `no_fr` DESC";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":to"=>$to));

		while($result = $stmt->fetchObject()){

			$no = $result->from_fr;

			$nick_query = "SELECT `nick_acnt` FROM `account` WHERE `no_acnt` = :no";
			$nick_stmt = $pdo->prepare($nick_query);
			$nick_stmt->execute(array(":no"=>$no));

			$nick = $nick_stmt->fetchObject();

			$result->nick_acnt = $nick->nick_acnt;

			$arr[] = $result;
		}


		print_r(json_encode(array("result"=>$arr)));
	}


	//회원가입 아이디 중복확인
	else if($cmd === "duplicatedId"){
		$id = $req['id'];

		$query = "SELECT COUNT(*) as cnt FROM `account` WHERE `id_acnt` = :id";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":id"=>$id));

		$result = $stmt->fetchObject();

		if($result->cnt > 0) print_r(json_encode(array("result"=>"DUPLICATED")));
		else if(intval($result->cnt) === 0) print_r(json_encode(array("result"=>"SAFE")));
		else print_r(json_encode(array("result"=>"FAIL")));
	}


	//회원 가입
	else if($cmd === "signUp"){

		
		$id = $req['id'];
		$rawPw = $req['pw'];
		$pw = hash("sha256",$rawPw);
		$nick = $req['nick'];

		$name = $req['name'];
		$phone = $req['phone'];
		$email = $req['email'];
		$intro = $req['intro'];//http://localhost:8888/wing.php?cmd=signUp&id=b&pw=b&token=b&nick=b&name=b&phone=b&email=b&self=b

		$query = "INSERT INTO `account` (`id_acnt`, `pw_acnt`, `nick_acnt`) VALUES (:id, :pw, :nick)";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":id"=>$id, ":pw"=>$pw, ":nick"=>$nick));

		$acnt = $pdo->lastInsertId();
	

		$query = "INSERT INTO `sensitive_info` (`acnt_si`, `name_si`, `phone_si`, `email_si`, `intro_si`) VALUES (:acnt, HEX(AES_ENCRYPT(:name, :key)), HEX(AES_ENCRYPT(:phone, :key)), HEX(AES_ENCRYPT(:email, :key)), HEX(AES_ENCRYPT(:intro, :key)))";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(
			":acnt"=>$acnt,
			":name"=>$name,
			":phone"=>$phone,
			":email"=>$email,
			":intro"=>$intro,
			":key"=>$rawPw
		));


		$query = "INSERT INTO `public_info` (`acnt_pi`, `intro_pi`) VALUES (:acnt, '비공개')";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));


		print_r(json_encode(array("result"=>"Success")));
	}

	//비번 검사 
	else if($cmd === "checkPw"){

		$acnt = $req['acnt'];
		$pw = $req['pw'];

		$query = "SELECT `pw_acnt` FROM `account` WHERE `no_acnt` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$account = $stmt->fetchObject();

		if(hash("sha256",$pw) === $account->pw_acnt){
			print_r(json_encode(array("result"=>"SAME", "pw"=>$pw)));
		}
		else{
			print_r(json_encode(array("result"=>"WRONG")));
		}
	}


	//비번 변경
	else if($cmd === "changePw"){

		$acnt = $req['acnt'];
		$bfPw = $req['bfPw'];
		$rawPw = $req['pw'];
		$pw = hash("sha256",$rawPw);


		$query = "UPDATE `account` SET `pw_acnt` = :pw WHERE `no_acnt` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":pw"=>$pw, ":acnt"=>$acnt));

		$query = "SELECT * FROM `sensitive_info` WHERE `acnt_si` = :anct";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "SELECT AES_DECRYPT(UNHEX(`name_si`),:pw) as name_si, AES_DECRYPT(UNHEX(`phone_si`),:pw) as phone_si, AES_DECRYPT(UNHEX(`email_si`),:pw) as email_si, AES_DECRYPT(UNHEX(`intro_si`),:pw) as intro_si FROM `sensitive_info` WHERE `acnt_si` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":pw"=>$bfPw, ":acnt"=>$acnt));

		$result = $stmt->fetchObject();

		$query = "UPDATE `sensitive_info` SET `name_si` = HEX(AES_ENCRYPT(:name, :key)), `phone_si` = HEX(AES_ENCRYPT(:phone, :key)), `email_si` = HEX(AES_ENCRYPT(:email, :key)), `intro_si` = HEX(AES_ENCRYPT(:intro, :key)) WHERE `anct_si` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(
			":acnt"=>$acnt,
			":name"=>$result->name_si,
			":phone"=>$result->phone_si,
			":email"=>$result->email_si,
			":intro"=>$result->intro_si,
			":key"=>$rawPw
		));

		print_r(json_encode(array("result" => "Success")));
	}

	//회원 탈퇴
	else if($cmd === "unregister"){

		$acnt = $req['acnt'];

		$query = "DELETE FROM `wing_info` WHERE `from_wi` = :acnt OR `to_wi` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "DELETE FROM `device_info` WHERE `acnt_di` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "DELETE FROM `sensitive_info` WHERE `acnt_si` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "DELETE FROM `public_info` WHERE `acnt_pi` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "DELETE FROM `friend_req` WHERE `from_fr` = :acnt OR `to_fr` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		$query = "DELETE FROM `account` WHERE `no_acnt` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt));

		print_r(json_encode(array("result" => "Success")));
	}

	//정보 수정 
	else if($cmd === "changeInfo"){

		$acnt = $req['acnt'];
		$pw = $req['pw'];
		$nick = $req['nick'];
		$name = $req['name'];
		$phone = $req['phone'];
		$email = $req['email'];
		$intro = $req['intro'];
		$nameCk = $req['nameCk'];
		$phoneCk = $req['phoneCk'];
		$emailCk = $req['emailCk'];
		$introCk = $req['introCk'];


		$query = "UPDATE `account` SET `nick_acnt` = :nick WHERE `no_acnt` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(":acnt"=>$acnt, ":nick"=>$nick));

		$query = "UPDATE `sensitive_info` SET `name_si` = HEX(AES_ENCRYPT(:name, :key)), `phone_si` = HEX(AES_ENCRYPT(:phone, :key)), `email_si` = HEX(AES_ENCRYPT(:email, :key)), `intro_si` = HEX(AES_ENCRYPT(:intro, :key)) WHERE `anct_si` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(
			":acnt"=>$acnt,
			":name"=>$name,
			":phone"=>$phone,
			":email"=>$email,
			":intro"=>$intro,
			":key"=>$pw
		));

		if($nameCk === "false") $name = "비공개";
		if($phoneCk === "false") $phone = "비공개";
		if($emailCk === "false") $email = "비공개";
		if($introCk === "false") $intro = "비공개";

		$query = "UPDATE `public_info` SET `name_pi` = :name, `phone_pi` = :phone, `email_pi` = :email, `intro_pi` = :intro WHERE `acnt_pi` = :acnt";
		$stmt = $pdo->prepare($query);
		$stmt->execute(array(
			":acnt"=>$acnt,
			":name"=>$name,
			":phone"=>$phone,
			":email"=>$email,
			":intro"=>$intro
		));

		print_r(json_encode(array("result" => "Success")));
	}
?>